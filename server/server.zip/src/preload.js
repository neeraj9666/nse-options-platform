const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  playbackStep: (params) =>
    ipcRenderer.invoke('playback-step', params),
});
