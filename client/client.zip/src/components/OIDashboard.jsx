import React from 'react';

export default function OIDashboard() {
    return (
        <div className="h-40 flex items-center justify-center border-b border-[#222] text-gray-500">
            OI Charts / Heatmap Area
        </div>
    );
}
