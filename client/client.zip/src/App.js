import React, { useCallback, useEffect, useRef, useState } from 'react';
import MasterControlBar from './components/MasterControlBar';
import TimeTravelBar from './components/TimeTravelBar';
import OptionChainTable from './components/OptionChainTable';

export default function App() {
  // ===== Core UI State =====
  const [viewMode, setViewMode] = useState('BOTH');
  const [rows, setRows] = useState([]);
  const [currentTime, setCurrentTime] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);

  // ===== Locked context (for now) =====
  const symbol = 'NIFTY';
  const expiry = '2025-05-29';

  // ===== Ref to avoid stale closure in setInterval =====
  const currentTimeRef = useRef(currentTime);
  useEffect(() => {
    currentTimeRef.current = currentTime;
  }, [currentTime]);

  // ===== Single playback step (DB decides time) =====
  const step = useCallback(async (direction = 'NEXT') => {
    const res = await window.api.playbackStep({
      symbol,
      expiry,
      currentTime: currentTimeRef.current,
      direction,
    });

    if (!res || !res.success) {
      console.warn('⛔ No more data in this direction');
      setIsPlaying(false);
      return;
    }

    setCurrentTime(res.time);
    setRows(res.rows);
  }, [symbol, expiry]);

  // ===== Initial load (first valid snapshot) =====
  useEffect(() => {
    step('NEXT');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ===== Playback loop =====
  useEffect(() => {
    if (!isPlaying) return;

    const id = setInterval(() => {
      step('NEXT');
    }, 1000); // 1 tick per second (can be tuned later)

    return () => clearInterval(id);
  }, [isPlaying, step]);

  // ===== UI handlers =====
  const handlePlay = () => setIsPlaying(true);
  const handlePause = () => setIsPlaying(false);
  const handleNext = () => step('NEXT');
  const handlePrev = () => step('PREV');

  // ===== Render =====
  return (
    <div className="flex flex-col h-screen bg-[#09090b] text-gray-200">
      <MasterControlBar
        symbol={symbol}
        expiry={expiry}
        viewMode={viewMode}
        setViewMode={setViewMode}
      />

      <TimeTravelBar
        isPlaying={isPlaying}
        onPlay={handlePlay}
        onPause={handlePause}
        onNext={handleNext}
        onPrev={handlePrev}
        currentTime={currentTime}
      />

      <OptionChainTable
        data={rows}
        viewMode={viewMode}
      />
    </div>
  );
}
